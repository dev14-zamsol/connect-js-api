# connect-js-api
[![Build Status](https://travis-ci.org/spotware/connect-js-api.svg?branch=master)](https://travis-ci.org/spotware/connect-js-api)

A connector SDK for [Spotware Connect Open API](https://connect.spotware.com/docs/api-reference) in JavaScript and Node.js
